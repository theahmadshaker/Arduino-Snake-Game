# Arduino-Snake-Game
This is my first "Arduino Snake Game" which you can play on an 8x8 LED matrix, and control the direction of the snake using a joystick.
